import torch.nn as nn
import torch.nn.functional as F
import torch

import torch.optim as optim
import sys, os
sys.path.append(os.getcwd())
import numpy as np
import torch
import random
import shutil

import pickle
from tqdm import tqdm
from datetime import datetime
from torch.utils.tensorboard import SummaryWriter
# from multi_step_prediction.dataset import PrisonerLocationDataset, create_dataset
# from multi_step_prediction.utils_msp import proba_distribution, calculate_loss, plot_gaussian_heatmap
from torch.utils.data import Dataset, DataLoader
# from multi_step_prediction.dataset import create_dataset, create_dataset_sequence, create_dataset_weighted, create_dataset_sequence_weighted

class EncoderRNN(nn.Module):
    def __init__(self, input_dim, hidden_dim, num_layers=1):

        super(EncoderRNN, self).__init__()

        self.input_dim = input_dim
        self.hidden_dim = hidden_dim
        self.num_layers = num_layers

        self.lstm = nn.LSTM(input_size=input_dim, hidden_size=hidden_dim, num_layers=num_layers, batch_first=True)
    
    @property
    def device(self):
        return next(self.parameters()).device

    def forward(self, x, hidden_state=None):
        batch_size = x.size(0)
        x = x.to(self.device).float()
        if hidden_state is None:
            # Initializing the hidden state for the first input with zeros
            h0 = torch.zeros(self.num_layers, batch_size, self.hidden_dim).requires_grad_().to(self.device)

            # Initializing the cell state for the first input with zeros
            c0 = torch.zeros(self.num_layers, batch_size, self.hidden_dim).requires_grad_().to(self.device)
        else:
            h0, c0 = hidden_state
        out, (hn, cn) = self.lstm(x, (h0, c0))

        # Reshaping the output
        # out = out[:, -1, :] # Hidden output from all timesteps out[:, -1, :] is the hidden output from the last timestep == hn
        hn = hn.view(-1, hn.shape[-1])
        return hn